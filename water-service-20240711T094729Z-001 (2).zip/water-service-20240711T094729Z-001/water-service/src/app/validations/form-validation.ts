import { z } from 'zod'
import { FormValidationConstants } from '../constants/form-validation-constants'

export const UserFormDetailValidation = z.object({
    email: z
        .string()
        .email({ message: FormValidationConstants.INVALID_EMAIL })
        .min(5, FormValidationConstants.MISSING_EMAIL),
    lastName: z.string().min(1, FormValidationConstants.LAST_NAME_VALIDATION),
    firstName: z.string().min(3, FormValidationConstants.FIRST_NAME_VALIDATION),
    phoneNo: z.string({ description: FormValidationConstants.MISSING_PHONE_NO }),
    state: z.string(),
    pincode: z.number(),
    service: z.string(),
    address1: z.string(),
    address2: z.string(),
    country: z.string(),
    date: z.string()
})
