import { Button } from '@/components/ui/button'
import Link from 'next/link'

 const Root = () => {
    return (
        <>
            <div className="flex flex-col max-lg:text-sm justify-center items-center w-screen h-screen px-14">
                <div >
                    {' '}
                    <blockquote className="italic text-light-wisteria-300"  data-testid="quote">
                        {`"Thousands Have Lived Without Love, Not One Without Water"`}
                    </blockquote>
                    <blockquote className="text-end italic text-light-wisteria-300">
                        - W.H.Auden
                    </blockquote>
                    <Link href="/home" >
                        <Button variant={'wisteria'} className="mt-8 max-lg:w-full">
                            Continue
                        </Button>
                    </Link>
                </div>
            </div>
        </>
    )
}

export default Root
