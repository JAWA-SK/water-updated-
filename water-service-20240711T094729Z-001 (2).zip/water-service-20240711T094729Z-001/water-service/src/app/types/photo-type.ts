export type PhotoResponse = {
    page: number
    per_page: number
    photos: RawPhoto[]
}

export type RawPhoto = {
    id: number
    url: string
    photographer: string
    photographer_url: string
    avg_color: string;
    alt: string
    src: {
        original: string
        large2x: string
        large: string
        medium: string
        small: string
        tiny: string
        portrait: string
    }
}

