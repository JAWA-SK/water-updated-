export type ServiceTypes = {
    type: string
    value: string
}
