export type UserFormDetail = {
    email: string
    lastName: string
    firstName: string
    phoneNo: string
    date: string
    address1: string
    address2: string
    state: string
    country: string
    service: string
}
