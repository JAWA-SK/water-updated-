export type EmailType = {
    from: {
        name: string
        address: string
    }
    to: string
    subject: string
    html: string
    attachments?: {
        filename: string
        path: string
    }
}
