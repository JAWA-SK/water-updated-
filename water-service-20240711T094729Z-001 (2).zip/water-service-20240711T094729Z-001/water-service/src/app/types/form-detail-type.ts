export type FormDetail = {
    email: string
    firstName: string
    lastName: string
    date: string
    service: string
    pincode: number
    address1: string
    address2: string
    phoneNo: string
    country: string
    state: string
}
