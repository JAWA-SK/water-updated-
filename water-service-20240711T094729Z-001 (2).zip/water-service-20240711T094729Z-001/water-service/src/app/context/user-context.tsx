import React from 'react'

const UserContext = () => {
    return <div></div>
}

export default UserContext
