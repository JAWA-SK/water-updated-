import { FaRegQuestionCircle } from "react-icons/fa";
import { FaImage, FaWpforms } from "react-icons/fa6";
import { IoIosContacts, IoIosPeople } from "react-icons/io";
import { IoHome } from "react-icons/io5";

export const NavBar = [
  {
    label: "Home",
    icon: <IoHome />,
    href: "/home",
  },
  {
    label: "Form",
    icon: <FaWpforms />,
    href: "/form",
  },
  {
    label: "Gallery",
    icon: <FaImage />,
    href: "/gallery",
  },
  {
    label: "About Us",
    icon: <IoIosPeople />,
    href: "/about",
  },
  {
    label: "Contact",
    icon: <IoIosContacts />,
    href: "/contact",
  },
  {
    label: "Support",
    icon: <FaRegQuestionCircle />,
    href: "/",
  },
];
