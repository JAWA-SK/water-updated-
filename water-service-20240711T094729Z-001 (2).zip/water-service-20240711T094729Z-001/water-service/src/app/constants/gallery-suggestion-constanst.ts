export const Suggestions = [
  { type: "Animal" },
  { type: "Mountains" },
  { type: "Monuments" },
  { type: "Poverty" },
  { type: "trees" },
  { type: "Sports" },
  { type: "Countries" },                                                    
];
