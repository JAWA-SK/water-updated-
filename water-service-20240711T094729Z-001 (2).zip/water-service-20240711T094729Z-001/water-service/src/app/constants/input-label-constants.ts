export const InputLabels = {
    SUBMIT_FORM: 'Submit Form',
    COMBO_BOX: 'combobox',
    OPTION: 'option',
    BUTTON: 'button'
}
