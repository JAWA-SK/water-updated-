import { ServiceTypes } from '../types/service-type'

export const states = [
    'Andhra Pradesh',
    'Arunachal Pradesh',
    'Assam',
    'Bihar',
    'Chhattisgarh',
    'Gujarat',
    'Haryana',
    'Himachal Pradesh',
    'Jammu and Kashmir',
    'Goa',
    'Jharkhand',
    'Karnataka',
    'Kerala',
    'Madhya Pradesh',
    'Maharashtra',
    'Manipur',
    'Meghalaya',
    'Mizoram',
    'Nagaland',
    'Odisha',
    'Punjab',
    'Rajasthan',
    'Sikkim',
    'Tamil Nadu',
    'Telangana',
    'Tripura',
    'Uttarakhand',
    'Uttar Pradesh',
    'West Bengal',
    'Andaman and Nicobar Islands',
    'Chandigarh',
    'Dadra and Nagar Haveli',
    'Daman and Diu',
    'Delhi',
    'Lakshadweep',
    'Puducherry'
]
export const Service: ServiceTypes[] = [
    {
        type: 'Service for ponds',
        value: 'ponds'
    },
    {
        type: 'Service for lakes',
        value: 'lakes'
    },
    {
        type: 'Service for unmaintained wells',
        value: 'wells'
    },
    {
        type: 'Service for near by water bodies',
        value: 'water bodies'
    },
    {
        type: 'Service for tank cleaning (min 1500L)',
        value: 'tanks'
    },
    {
        type: 'Others',
        value: 'others'
    }
]
