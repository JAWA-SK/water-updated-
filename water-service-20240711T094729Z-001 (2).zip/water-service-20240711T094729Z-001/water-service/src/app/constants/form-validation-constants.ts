export const FormValidationConstants = {
    FIRST_NAME_VALIDATION: 'field must contain at least 3 characters',
    LAST_NAME_VALIDATION: 'field must contain at least 1 characters',
    MIN_PINCODE_VALIDATION: 'field must contain at least 6 characters',
    MAX_PINCODE_VALIDATION: "field mustn't contain at least 1 characters",
    INVALID_EMAIL: 'invalid email',
    MISSING_FIRST_NAME: 'Missing First Name',
    MISSING_LAST_NAME: 'Missing Last Name',
    MISSING_EMAIL: 'Missing Email',
    MISSING_ADDRESS: 'Missing Address',
    MISSING_PINCODE: 'Missing Pincode',
    MISSING_PHONE_NO: 'Missing Phone Number'
}

export const FormPlaceHolders = {
    FIRST_NAME: 'firstName',
    LAST_NAME: 'lastName',
    EMAIL: 'email',
    ADDRESS_1: 'example door number, street....',
    ADDRESS_2: 'landmark',
    MOBILE: 'mobile',
    PINCODE: 'pincode'
}
