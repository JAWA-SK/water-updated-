export const FormLabels = {
    FIRST_NAME: 'First Name:',
    LAST_NAME: 'Last Name:',
    EMAIL: 'Email:',
    DATE: 'Service Date:',
    ADDRESS_1: 'Address Line 1:',
    ADDRESS_2: 'Address Line 2:',
    SERVICE: 'Choose Service:',
    COUNTRY: 'Country:',
    STATE: 'State:',
    MOBILE: 'Mobile:',
    PIN_CODE: 'Pin Code:'
}
