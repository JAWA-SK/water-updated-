export const rolesAndNames = [
    {
        name: 'Jawahar A',
        role: 'Founder'
    },
    {
        name: 'Sathya R',
        role: 'Developer'
    },
    {
        name: 'Priyanka A',
        role: 'Desinger'
    },
    {
        name: 'Logesh',
        role: 'Finance'
    },
    {
        name: 'Kasthuri',
        role: 'Sales'
    }
]