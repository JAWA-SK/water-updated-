
import FormComponent from './form-component'
import TextComponent from './text-component'

const Form = () => {
    return (
        <div className=" max-lg:flex-col w-screen gap-5 px-10 py-5 flex  overflow-hidden">
            <TextComponent />
            <FormComponent />
        </div>
    )
}
export default Form
