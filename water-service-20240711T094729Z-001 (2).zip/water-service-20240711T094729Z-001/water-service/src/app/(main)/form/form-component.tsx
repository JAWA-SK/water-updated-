"use client";

import { Service, states } from "@/app/constants/form-input-constants";
import { FormLabels } from "@/app/constants/form-label-constants";
import { FormPlaceHolders } from "@/app/constants/form-validation-constants";
import { UserFormDetail } from "@/app/types/user-details-type";
import { UserFormDetailValidation } from "@/app/validations/form-validation";
import { Button } from "@/components/ui/button";
import { DatePicker } from "@/components/ui/date-picker";
import Lottie from "lottie-react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import { sendConfirmationMail } from "../lib/api";
import { useState } from "react";
import confetti from "../../../../public/assets/confetti.json";

type UserForm = z.infer<typeof UserFormDetailValidation>;
const FormComponent = () => {
  const [booked, setBooked] = useState(false);
  const {
    handleSubmit,
    register,
    control,
    formState: { errors },
  } = useForm<UserForm>({
    defaultValues: {
      email: "",
      state: "Tamil Nadu",
      firstName: ``,
      lastName: ``,
      pincode: 0,
      date: "",
      country: "India",
      service: "",
      address1: "",
      address2: "",
      phoneNo: "",
    },
    mode: "all",
  });

  async function submitForm(data: UserFormDetail) {
    await sendConfirmationMail(data);
    setTimeout(() => {
      setBooked(false);
    }, 3000);
    setBooked(true);
    toast.success(`Hi ${data.firstName}, Booking Success Check Your Inbox.`);
  }
  return (
    <div className="lg:w-[50%] ">
      <form
        className="h-fit bg-light-wisteria-900/40 rounded-lg opacity-100 p-3 font-semibold"
        onSubmit={() => handleSubmit(submitForm)}
      >
        <div className="flex flex-col  w-full h-full space-y-10 text-light-wisteria-200">
          <div className="flex max-lg:flex-col max-lg:gap-6 lg:justify-between w-full text-md">
            <div>
              <label>{FormLabels.FIRST_NAME}</label>
              <Input
                type="text"
                id="firstName"
                placeholder={FormPlaceHolders.FIRST_NAME}
                className="bg-light-wisteria-50 text-light-wisteria-700"
                {...register("firstName", {
                  required: {
                    value: true,
                    message: "Missing First Name",
                  },
                  minLength: {
                    value: 3,
                    message: "field must contain at least 3 characters",
                  },
                })}
              ></Input>
              {errors.firstName && (
                <>
                  <p className="text-red-600 text-[14px] text-start font-normal">
                    {errors.firstName.message}
                  </p>
                </>
              )}
            </div>
            <div>
              <label>{FormLabels.LAST_NAME}</label>
              <Input
                type="text"
                id="lastName"
                placeholder={FormPlaceHolders.LAST_NAME}
                className="bg-light-wisteria-50 text-light-wisteria-700"
                {...register("lastName", {
                  required: {
                    value: true,
                    message: "Missing Last Name",
                  },
                  minLength: {
                    value: 1,
                    message: "field must contain at least 1 characters",
                  },
                })}
              ></Input>
              {errors.lastName && (
                <>
                  <p className="text-red-600 text-[14px] text-start font-normal">
                    {errors.lastName.message}
                  </p>
                </>
              )}
            </div>
            <div>
              <label>{FormLabels.EMAIL}</label>
              <Input
                type="email"
                id="email"
                placeholder={FormPlaceHolders.EMAIL}
                className="bg-light-wisteria-50 text-light-wisteria-700"
                {...register("email", {
                  required: {
                    value: true,
                    message: "Missing Email",
                  },
                  pattern: {
                    value: /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i,
                    message: "invalid email address",
                  },
                })}
              ></Input>
              {errors.email && (
                <>
                  <p className="text-red-600 text-[14px] text-start font-normal">
                    {errors.email.message}
                  </p>
                </>
              )}
            </div>
          </div>
          <div className="flex flex-col w-full h-full ">
            <div className="flex justify-between w-full text-md max-lg:flex-col max-lg:gap-6">
              <div>
                <label>{FormLabels.MOBILE}</label>
                <Input
                  type="text"
                  id="mobile"
                  placeholder={FormPlaceHolders.MOBILE}
                  className="bg-light-wisteria-50 text-light-wisteria-700"
                  {...register("phoneNo", {
                    required: {
                      value: true,
                      message: "Missing Phone Number",
                    },
                    minLength: {
                      value: 9,
                      message: "phone number cannot be less than 10 digits",
                    },
                  })}
                ></Input>
                {errors.phoneNo && (
                  <>
                    <p className="text-red-600 text-[14px] text-start font-normal">
                      {errors.phoneNo.message}
                    </p>
                  </>
                )}
              </div>
              <div>
                <label>{FormLabels.DATE}</label>
                <div>
                  <DatePicker></DatePicker>
                </div>
              </div>
              <div>
                <label>{FormLabels.SERVICE}</label>
                <Select defaultValue="ponds">
                  <SelectTrigger className="w-[225px] bg-light-wisteria-50 text-light-wisteria-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Service.map((service, index) => {
                      return (
                        <SelectItem value={service.value} key={index}>
                          {service.type}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-10 ">
            <div>
              <label>{FormLabels.ADDRESS_1}</label>
              <Input
                type="text"
                id="address1"
                placeholder={FormPlaceHolders.ADDRESS_1}
                className="bg-light-wisteria-50 text-light-wisteria-700"
                {...register("address1", {
                  required: {
                    value: true,
                    message: "Missing Address",
                  },
                  minLength: {
                    value: 10,
                    message: "field must contain at least 10 characters",
                  },
                })}
              ></Input>
              {errors.address1 && (
                <>
                  <p className="text-red-600 text-[14px] text-start font-normal">
                    {errors.address1.message}
                  </p>
                </>
              )}
            </div>
            <div>
              <label>{FormLabels.ADDRESS_2}</label>
              <Input
                type="text"
                id="address2"
                placeholder={FormPlaceHolders.ADDRESS_2}
                className="bg-light-wisteria-50 text-light-wisteria-700"
              ></Input>
            </div>
          </div>
          <div>
            {" "}
            <div className="flex flex-col w-full h-full  ">
              <div className="flex justify-between w-full text-md max-lg:flex-col max-lg:gap-6">
                <div>
                  <label>{FormLabels.STATE}</label>
                  <Select defaultValue={"Tamil Nadu"}>
                    <SelectTrigger className="w-[225px] bg-light-wisteria-50 text-light-wisteria-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {states.map((values, index) => {
                        return (
                          <SelectItem key={index} value={values}>
                            {values}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label>{FormLabels.COUNTRY}</label>
                  <Select defaultValue="India">
                    <SelectTrigger className="w-[225px] bg-light-wisteria-50 text-light-wisteria-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="India" disabled>
                        India
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label>{FormLabels.PIN_CODE}</label>
                  <Input
                    type="text"
                    id="pincode"
                    data-testid="pincode"
                    placeholder="Pincode"
                    className="bg-light-wisteria-50 text-light-wisteria-700"
                    defaultValue={"600103"}
                    {...register("pincode", {
                      required: {
                        value: true,
                        message: "Missing Pincode",
                      },
                      minLength: {
                        value: 6,
                        message: "field must contain at least 6 characters",
                      },
                      maxLength: {
                        value: 6,
                        message: "field mustn't contain more than 6 characters",
                      },
                    })}
                  ></Input>
                  {errors.pincode && (
                    <>
                      <p className="text-red-600 text-[14px] text-start font-normal">
                        {errors.pincode.message}
                      </p>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
      <div className="flex items-center w-full justify-center mt-5 relative">
        <Button
          variant={"wisteria"}
          type="submit"
          onClick={handleSubmit(submitForm)}
        >
          Submit Form
        </Button>
        {booked ? (
          <Lottie animationData={confetti} className="w-20 absolute"></Lottie>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

export default FormComponent;
