import {
    Accordion,
    AccordionContent,
    AccordionTrigger,
    AccordionItem
} from '@/components/ui/accordion'
import 'easymde/dist/easymde.min.css'
import { useEffect, useState } from 'react'

const TextComponent = () => {
    return (
        <div className="flex flex-col gap-5 lg:w-[50%]  text-container text-light-wisteria-200">
            <Accordion type="single" collapsible className=" space-y-5" defaultValue="quotes">
                <AccordionItem
                    value="good"
                    className="border-2 flex-1 border-light-wisteria-950 rounded-md px-2 w-full "
                >
                    <AccordionTrigger>
                        <div className="flex justify-between w-full">
                            <div className="font-bold text-center  text-xl text-light-wisteria-400 w-full">
                                Thats Sad
                            </div>
                        </div>
                    </AccordionTrigger>

                    <AccordionContent className="p-5 ">
                        <ul className="list-disc space-y-5">
                            <li className="list-item mt-4  items-center space-x-3">
                                <span>
                                    Only{' '}
                                    <span className="text-3xl text-light-wisteria-500">20%</span> of
                                    waste water is treated.
                                </span>
                            </li>
                            <li className="list-item  items-center space-x-3">
                                <span>
                                    The average family can waste{' '}
                                    <span className="text-3xl text-light-wisteria-500">180</span>{' '}
                                    gallons per week, or{' '}
                                    <span className="text-3xl text-light-wisteria-500">9,400</span>{' '}
                                    gallons of water annually, from household leaks.
                                </span>
                            </li>
                            <li className="list-item  items-center space-x-3">
                                <span>Rain water is no longer safe to drink, Study Says</span>
                            </li>
                        </ul>
                    </AccordionContent>
                </AccordionItem>
                <AccordionItem
                    className="border-2 flex-1 border-light-wisteria-950 rounded-md px-2 w-full"
                    value="bad"
                >
                    <AccordionTrigger>
                        <div className="flex justify-between w-full">
                            <div className="font-bold text-center text-xl text-light-wisteria-400 w-full">
                                Thats Good
                            </div>
                        </div>
                    </AccordionTrigger>

                    <AccordionContent className="p-5">
                        <ul className="list-disc space-y-5">
                            <li className="list-item mt-4  items-center space-x-3">
                                <span>
                                    First Nations Governments agree to bring{' '}
                                    <span className="text-3xl text-light-wisteria-500">Salmon</span>{' '}
                                    back to Upper Columbia River
                                </span>
                            </li>
                            <li className="list-item  items-center space-x-3">
                                <span>
                                    <span className="text-3xl text-light-wisteria-500">
                                        Jaden Smith
                                    </span>{' '}
                                    donates second mobile water filtration system.
                                </span>
                            </li>
                            <li className="list-item  items-center space-x-3">
                                <span>
                                    Addressing sea level rise through citizen{' '}
                                    <span className="text-light-wisteria-500 text-3xl">
                                        Science
                                    </span>
                                </span>
                            </li>
                        </ul>
                    </AccordionContent>
                </AccordionItem>
                <AccordionItem
                    className="border-2 flex-1 border-light-wisteria-950 rounded-md px-2 w-full "
                    value="quotes"
                >
                    <AccordionTrigger>
                        <div className="flex justify-between w-full">
                            <div className="font-bold text-center text-xl text-light-wisteria-400 w-full">
                                Quotes
                            </div>
                        </div>
                    </AccordionTrigger>

                    <AccordionContent className="p-5">
                        <div className="flex flex-col gap-5 italic text-center">
                            <blockquote>
                                <span>
                                    {`"Pure water is the world's first and foremost medicine."`}
                                </span>
                                <span className="block text-right text-light-wisteria-700">
                                    - Slovakian Proverb
                                </span>
                            </blockquote>
                            <blockquote>
                                <span>{`"When the well is dry, we know the value of water"`}</span>
                                <span className="block text-right text-light-wisteria-700">
                                    - Benjamin Franklin
                                </span>
                            </blockquote>
                            <blockquote>
                                <span>{`"We forget that water and life cycles are one."`}</span>
                                <span className="block text-right text-light-wisteria-700">
                                    - Jacques Yves Cousteau
                                </span>
                            </blockquote>
                            <div className="w-full">
                                <blockquote>
                                    <span>
                                        {` "If there is magic on the planet, it is contained in water."`}
                                    </span>
                                    <span className="block text-right text-light-wisteria-700">
                                        - Loren Eisley
                                    </span>
                                </blockquote>
                            </div>
                        </div>
                    </AccordionContent>
                </AccordionItem>
            </Accordion>
        </div>
    )
}

export default TextComponent
