import { UserFormDetail } from '@/app/types/user-details-type'
import { NextRequest, NextResponse } from 'next/server'
import { sendMail, transporter } from '../../config/nodemailer'

export async function POST(req: NextRequest) {
    const data = (await req.json()) as UserFormDetail
    console.log({ data })

    try {
        await sendMail(transporter, {
            from: {
                name: 'Water-Doc Team!',
                address: 'jawajawa821@gmail.com'
            },
            to: data.email,
            subject: 'Booking SuccessFull',
            html: `<h1> Hi ${data.firstName}</h1><br/><p>We'll be arriving soon${data.date}</p>`,
            attachments: {
                filename: 'siuu.jpg',
                path: 'public/assets/save-water.png'
            }
        })
        return NextResponse.json({ success: true })
    } catch (err) {
        NextResponse.json({ success: false })
    }
    return NextResponse.json({ success: true })
}
