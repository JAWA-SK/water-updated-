"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ReactNode, useState } from "react";
import { NavBar } from "../constants/navigation-constants";
import {
  DropdownMenu,
  DropdownMenuContent,
} from "@radix-ui/react-dropdown-menu";
import {
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { IoMdMenu } from "react-icons/io";

export default function HomeLayout({ children }: { children: ReactNode }) {
  const currentPath = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleMenuToggle = () => {
    setMenuOpen(!menuOpen);
  };

  const handleMenuClose = () => {
    setMenuOpen(false);
  };
  function isCurrentPath(expectedPath: string, currentPath: string) {
    const escapedExpectedPath = expectedPath.replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    );
    const regex = new RegExp(`^${escapedExpectedPath}(\\/|$)`);
    return regex.test(currentPath);
  }
  return (
    <div>
      <div className=" flex justify-between px-10 py-5 relative max-lg:hidden">
        {NavBar.map((value, index) => {
          return (
            <>
              {" "}
              <Link
                key={index}
                href={value.href}
                className={`${isCurrentPath(value.href, currentPath) ? "text-light-wisteria-200 underline" : "text-light-wisteria-600 "} hover:text-light-wisteria-200 text-lg font-normal transition-all duration-150 ease-in`}
              >
                {value.label}
              </Link>
              {currentPath === value.href && (
                <div className="animate-nav-link-animation absolute top-0 left-0 h-1 w-[0%] rounded bg-light-wisteria-800 " />
              )}
            </>
          );
        })}
      </div>
      <div className=" w-screen lg:hidden ">
        <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen} >
          <DropdownMenuTrigger onClick={handleMenuToggle} className=" flex justify-end p-4 w-full ">
            <IoMdMenu
              size={35}
              className="text-light-wisteria-600/80 outline-none  "
            />
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-black w-screen z-10 h-screen ">
            <DropdownMenuLabel className="text-2xl text-light-wisteria-900 text-center">
              Menu
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="flex flex-col gap-4">
              {" "}
              {NavBar.map((value, index) => {
                return (
                  <>
                    {" "}
                    <Link
                      onClick={handleMenuClose}
                      key={index}
                      href={value.href}
                      className={`text-lg  bg-light-wisteria-900 px-5 py-3 rounded-lg w-40 text-center font-bold ${isCurrentPath(value.href, currentPath) ? "text-light-wisteria-200 bg-light-wisteria-500 " : "text-light-wisteria-100 "} `}
                    >
                      <div className="flex gap-2">
                        <span className="mt-[4px]">{value?.icon}</span>
                        <span>{value.label}</span>
                      </div>
                    </Link>
                  </>
                );
              })}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {children}
    </div>
  );
}
