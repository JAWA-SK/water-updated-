import Image from 'next/image'
import Link from 'next/link'
import water_man_2 from '../../../../public/assets/in-waterman.jpg'
import { FaArrowUpRightFromSquare } from 'react-icons/fa6'
const Home = () => {
    return (
        <>
            <div className="p-5 text-center w-full h-full flex gap-5">
                <div className="w-[50%] h-fit text-end">
                    <span className=" text-light-wisteria-400 text-[100px] font-semibold w-full">
                        What we do and
                    </span>
                    <ul className="text-light-wisteria-300 flex flex-col text-lg space-y-5">
                        <li>We clean and manage ponds, rivers and other water bodies near you.</li>
                        <li>
                            And control and movement of water resources to minimize damage to life
                            and to maximize efficient beneficial use.
                        </li>
                        <Link
                            href={'/about'}
                            className="underline hover:text-light-wisteria-600 transition-colors ease-in"
                        >
                            <div className="flex justify-end space-x-2 underline">
                                <span>Interested in delving deeper into our story </span>
                                <span>
                                    <FaArrowUpRightFromSquare className="h-8 w-4 " />
                                </span>
                            </div>{' '}
                        </Link>
                    </ul>
                </div>
                <div className="w-[50%] text-start h-fit">
                    <span className=" text-light-wisteria-600 text-[100px] font-semibold">
                        What you can do
                    </span>
                    <ul className="text-light-wisteria-600 flex flex-col text-lg space-y-5 ">
                        <li>
                            You can take actionable steps to mitigate or eliminate any issues or
                            you're in the right place.
                        </li>
                        <li>
                            We're here to back you up and your surroundings. All you need do is fill
                            the form with necessary details it takes a minute.{' '}
                        </li>
                        <Link
                            href={'/form'}
                            className="underline hover:text-light-wisteria-300 transition-colors ease-in  "
                        >
                            <div className="flex justify-start space-x-2 underline">
                                <span> Keep the momentum going, just one click to go </span>
                                <span>
                                    <FaArrowUpRightFromSquare className="h-8 w-4 " />
                                </span>
                            </div>{' '}
                        </Link>
                    </ul>
                </div>
            </div>
            <div className="text-light-wisteria-500/90 text-center text-2xl font-bold mt-10 ">
                {' '}
                Did you know?
            </div>
            <div className=" text-end flex p-10 ml-5 ">
                <div className=" w-[50%] space-y-10 flex flex-col text-light-wisteria-300 border-2 p-3 rounded-lg border-light-wisteria-400">
                    <span>
                        Rajendra Singh, also known as the "Waterman of India", is a water
                        conservationist and environmentalist from Alwar district, Rajasthan. He was
                        born on August 6, 1959. He has won the Ramon Magsaysay Award in 2001 and the
                        Stockholm Water Prize in 2015.
                    </span>
                    <span>
                        Singh is the driving force behind several initiatives to conserve water in
                        India. He revived traditional water storage techniques in abandoned parts of
                        Rajasthan's villages, and used traditional water harvesting techniques to
                        turn the region's drought-prone landscapes into thriving ecosystems
                    </span>
                    <span>
                        Singh is also the founder of the NGO Tarun Bharat Sangh (TBS), which was
                        established in 1975. He won the Magsaysay Award in 2001 and the Stockholm
                        Water Prize in 2015 for his contributions to social movements
                    </span>

                    <Link
                        href={'https://en.wikipedia.org/wiki/Rajendra_Singh'}
                        className="underline hover:text-light-wisteria-600 transition-colors ease-in italic"
                    >
                        Discover the fascinating story behind him.
                    </Link>
                </div>{' '}
                <div className="w-[50%] flex justify-center rounded-lg">
                    <Image
                        alt="rajendra singh"
                        className="rounded-lg brightness-90 border-4 border-light-wisteria-400"
                        src={water_man_2}
                        width={700}
                        height={600}
                        priority
                    ></Image>
                </div>
            </div>
        </>
    )
}

export default Home
