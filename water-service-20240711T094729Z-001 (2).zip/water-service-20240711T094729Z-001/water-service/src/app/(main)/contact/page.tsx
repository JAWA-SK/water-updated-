import {
    Card,
    CardContent
} from '@/components/ui/card'
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card'
import Link from 'next/link'
import { FaPercentage } from 'react-icons/fa'
import { FaLocationDot } from 'react-icons/fa6'
import { IoMdCall } from 'react-icons/io'
import { IoChatboxEllipsesSharp } from 'react-icons/io5'

const ContactPage = () => {
    return (
        <div className="p-5 ">
            <div className="text-[200px] font-semibold m-0 w-fit">
                <HoverCard>
                    <HoverCardTrigger>
                        {' '}
                        <span className="text-light-wisteria-400">Get In</span>
                        <span className="text-light-wisteria-700"> Touch</span>
                    </HoverCardTrigger>
                    <HoverCardContent className="w-fit h-fit text-sm bg-light-wisteria-300 text-light-wisteria-800 space-y-2">
                        <p>Email: support@waterdoc.com</p>
                        <p> Contact: 1234567890</p>
                    </HoverCardContent>
                </HoverCard>
            </div>
            <div className="flex justify-between">
                <Card className="w-80 h-[33vh] bg-light-wisteria-950 text-light-wisteria-100 border-light-wisteria-400 border-2 overflow-hidden">
                    <CardContent className="w-full h-full p-0 text-center">
                        <div className="bg-light-wisteria-800 w-full h-[33%] content-center text-center flex justify-center items-center">
                            <FaPercentage className=" w-12 h-12 " data-testid="percentage"/>
                        </div>
                        <div className="text-start px-5 py-2 flex flex-col h-[67%] justify-between">
                            <p className="text-2xl font-semibold block">Sales chat</p>
                            <p className="text-sm">
                                Talk to oir super team of assistance to solve your sales-related
                                problems
                            </p>
                            <p className="text-sm  underline hover:text-light-wisteria-600 cursor-pointer transition-colors duration-200">
                                sales@waterdoc.com
                            </p>
                        </div>
                    </CardContent>
                </Card>

                <Card className="w-80 h-[33vh] bg-light-wisteria-950 text-light-wisteria-100 overflow-hidden border-light-wisteria-400 border-2 ">
                    <CardContent className="w-full p-0 text-center h-full ">
                        <div className="bg-light-wisteria-800 w-full h-[33%] content-center text-center flex justify-center items-center">
                            <IoChatboxEllipsesSharp className=" w-12 h-12 " data-testid="chatBox"/>
                        </div>
                        <div className="text-start px-5 py-2 flex flex-col justify-between h-[67%] ">
                            <span className="text-2xl font-semibold block">Support chat</span>
                            <span className="text-sm">
                                Need further assistance? if the FAQs do not cover your questions,
                                write to us at our email address for help
                            </span>
                            <span className="text-sm underline hover:text-light-wisteria-600 cursor-pointer transition-colors duration-200">
                                support@waterdoc.com
                            </span>
                        </div>
                    </CardContent>
                </Card>
                <Card className="w-80  h-[33vh] bg-light-wisteria-950 text-light-wisteria-100 overflow-hidden border-light-wisteria-400 border-2 ">
                    <CardContent className="w-full p-0 text-center h-full ">
                        <div className="bg-light-wisteria-800 w-full h-[33%] content-center text-center flex justify-center items-center">
                            <FaLocationDot className=" w-12 h-12" data-testid="location"/>
                        </div>
                        <div className="text-start px-5 py-2 flex flex-col gap-2 justify-between h-[67%]">
                            <span className="text-2xl font-semibold block">Visit us</span>
                            <span className="text-sm">
                                Come and see where we work and what we do
                            </span>
                            <Link
                                href={
                                    'https://www.google.com/maps/@12.8412514,80.2209766,15z?entry=ttu'
                                }
                                className="text-sm   underline hover:text-light-wisteria-600 cursor-pointer transition-colors duration-200"
                            >
                                View on Google Maps
                            </Link>
                        </div>
                    </CardContent>
                </Card>
                <Card className="w-80  h-[33vh] bg-light-wisteria-950 text-light-wisteria-100 overflow-hidden border-light-wisteria-400 border-2 ">
                    <CardContent className="w-full p-0 text-center h-full ">
                        <div className="bg-light-wisteria-800 w-full h-[33%] content-center text-center flex justify-center items-center">
                            <IoMdCall className=" w-12 h-12 " data-testid="call" />
                        </div>
                        <div className="text-start px-5 py-2 flex flex-col gap-2 justify-between h-[67%]">
                            <span className="text-2xl font-semibold block">Call us</span>
                            <span className="text-sm">
                                We're glad to assist you from Monday-Friday 9AM-6PM{' '}
                            </span>
                            <div className="text-sm   underline hover:text-light-wisteria-600 cursor-pointer transition-colors duration-200">
                                +91 8870132424
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}

export default ContactPage
