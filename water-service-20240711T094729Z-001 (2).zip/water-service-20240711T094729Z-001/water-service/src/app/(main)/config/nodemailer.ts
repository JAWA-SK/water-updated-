import { EmailType } from '@/app/types/mail-option-type'
import nodemailer from 'nodemailer'
export const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
        user: String(process.env.EMAIL),
        pass: String(process.env.EMAIL_PASSWORD)
    }
})
export const sendMail = async (transporter: any, mailOptions: EmailType) => {
    try {
        await transporter.sendMail(mailOptions)
        console.log('mail sent')
    } catch (err) {
        console.log(err)
    }
}
