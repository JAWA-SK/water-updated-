import { UserFormDetail } from '@/app/types/user-details-type'

export const sendConfirmationMail = async (data: UserFormDetail) => {
    fetch('api/form', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
        }
    })
}
