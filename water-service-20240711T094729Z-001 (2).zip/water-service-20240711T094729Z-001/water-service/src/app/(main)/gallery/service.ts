import { PhotoResponse } from "@/app/types/photo-type";

export async function fetchData(
  search: string,
  limit: number
): Promise<PhotoResponse> {
  const searchQuery = search;
  const limited = limit;
  const response = await fetch(
    `https://api.pexels.com/v1/search?query=${searchQuery}&page=1&per_page=${limited}`,
    {
      headers: {
        Authorization:
          "wpiX7X0BirF94NYHbUwWv3oL2uHnfla0fPHLF5a1brO7IsjRzmcLqVyT",
      },
    }
  );
  const data = await response.json();
  return data;
}
