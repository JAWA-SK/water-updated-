import Gallery from '../gallery/gallery'

export default async function getPhotos() {
    return (
        <div>
            <Gallery></Gallery>
        </div>
    )
}
