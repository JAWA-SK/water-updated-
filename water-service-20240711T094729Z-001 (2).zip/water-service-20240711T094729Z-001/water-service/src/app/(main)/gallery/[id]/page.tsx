import { RawPhoto } from '@/app/types/photo-type'
import React from 'react'
import ViewPhotoPage from './view-photo'

const Photo = async ({ params }: { params: { id: string } }) => {
    const photo = await fetch(`https://api.pexels.com/v1/photos/${params.id}`, {
        headers: {
            Authorization:'wpiX7X0BirF94NYHbUwWv3oL2uHnfla0fPHLF5a1brO7IsjRzmcLqVyT'
        }
    })
    const data = (await photo.json()) as RawPhoto
    return (
        <div>
            <ViewPhotoPage data={data}></ViewPhotoPage>
        </div>
    )
}

export default Photo
