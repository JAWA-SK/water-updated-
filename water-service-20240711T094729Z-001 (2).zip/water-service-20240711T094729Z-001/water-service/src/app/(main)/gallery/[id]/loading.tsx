import { Skeleton } from '@/components/ui/skeleton'

export default function Loading() {
    return (
        <div className="p-5 justify-center flex items-center">
            <div className="flex p-5 bg-slate-400/40 w-[80%] rounded-md gap-5">
                <Skeleton className="w-96 rounded-md  bg-slate-400/40 "></Skeleton>
                <div className="flex flex-col gap-16 ">
                    <p className="  font-bold"></p>{' '}
                    <div className=" w-full  grid grid-flow-col grid-rows-2 gap-x-20 gap-y-10">
                        <Skeleton className="bg-slate-400/40  opacity-75  content-center rounded-md p-5  w-[25rem] h-[20vh]"></Skeleton>
                        <Skeleton className="bg-slate-400/40  opacity-75  content-center rounded-md p-5 cursor-pointer "></Skeleton>
                        <Skeleton className="bg-slate-400/40  opacity-75  content-center rounded-md p-5 cursor-pointer w-[25rem]"></Skeleton>
                        <Skeleton className="bg-slate-400/40  opacity-75  content-center rounded-md p-5 cursor-pointer w-[25rem]"></Skeleton>
                    </div>
                    <div className=" w-full  flex justify-center">
                        <Skeleton className="opacity-75 w-[20%] p-5 bg-slate-400/40 font-semibold "></Skeleton>
                    </div>
                </div>
            </div>
        </div>
    )
}
