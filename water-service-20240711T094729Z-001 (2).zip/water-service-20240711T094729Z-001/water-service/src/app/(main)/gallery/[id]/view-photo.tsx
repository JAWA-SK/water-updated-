"use client";
import { RawPhoto } from "@/app/types/photo-type";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { useRouter } from "next/navigation";

type ImageProps = {
  data: RawPhoto;
};

const ViewPhotoPage = ({ data }: ImageProps) => {
  const router = useRouter();
  return (
    <div className="p-5 justify-center flex items-center">
      <div className="flex p-5 bg-light-wisteria-950 border-2 border-white w-[80%] rounded-md gap-5">
        <Image
          src={data.src.original}
          alt=""
          width={500}
          height={300}
          className="w-96 rounded-md border-2 border-light-wisteria-100"
        ></Image>
        <div className="flex flex-col gap-16 ">
          <p className="text-2xl text-center  text-light-wisteria-200 font-serif font-bold">
            Find about the Image{" "}
          </p>{" "}
          <div className=" w-full font-serif  grid grid-flow-col grid-rows-2 gap-x-20 gap-y-10">
            <div className="bg-light-wisteria-300 border-4 opacity-75 border-white text-center content-center rounded-md p-5  w-[25rem] h-[20vh]">
              <p className="text-light-wisteria-900">Photo By</p>
              <span className="text-2xl  text-light-wisteria-900">
                {data.photographer}
              </span>
            </div>
            <div className="bg-light-wisteria-300 border-4 opacity-75 border-white text-center content-center rounded-md p-5 cursor-pointer ">
              <p className="text-light-wisteria-900">profile</p>
              <a
                href={data.photographer_url}
                className="text-2xl  text-light-wisteria-900 underline hover:text-light-wisteria-600 transition-colors duration-200"
              >
                Find his profile here
              </a>
            </div>
            <div className="bg-light-wisteria-300 border-4 opacity-75 border-white text-center content-center rounded-md p-5 cursor-pointer w-[25rem]">
              <p className="text-light-wisteria-900">About</p>
              <span className="text-2xl  text-light-wisteria-900">
                {data.alt}
              </span>
            </div>
            <div className="bg-light-wisteria-300 opacity-75 border-4 border-white text-center content-center rounded-md p-5 cursor-pointer">
              <p className="text-light-wisteria-900">Color code</p>
              <div className="flex gap-2 justify-center">
                <span className="text-2xl  text-light-wisteria-900">
                  {data.avg_color}
                </span>
              </div>
            </div>
          </div>
          <div className=" w-full  flex justify-center">
            <Button
              className="opacity-75 w-[20%] text-[16px] text-light-wisteria-800 font-semibold border-2 border-white bg-light-wisteria-300"
              variant={"default"}
              onClick={() => router.push("/gallery")}
            >
              Back To Gallery
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewPhotoPage;
