'use client'
import { PhotoResponse, RawPhoto } from '@/app/types/photo-type'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { ChangeEvent, useEffect, useState } from 'react'
import { fetchData } from './service'
import { Button } from '@/components/ui/button'
import { Suggestions } from '@/app/constants/gallery-suggestion-constanst'
import { FaHeart } from 'react-icons/fa'
import Loading from '@/components/ui/gallery-loader'

type PhotoProps = {
    photos: RawPhoto[]
}

const Gallery = () => {
    const handleClick = (id: number) => {
        router.push(`/gallery/${id}`)
    }
    const [search, setSearch] = useState('snow mountains')
    const [limit, setLimit] = useState(20)
    const [likes, setLikes] = useState<Record<number, boolean>>({})

    const [loading, setLoading] = useState(false)
    const [photos, setPhotos] = useState<RawPhoto[] | null>(null)
    async function handleChange(e: ChangeEvent<HTMLInputElement>) {
        e.preventDefault()
        e.target.value === '' ? setSearch('snow mountains') : setSearch(e.target.value)
    }

    async function apiCall(query: string, limited: number) {
        setLoading(true)
        const data = (await fetchData(query, limited)) as unknown as PhotoResponse
        setPhotos(data.photos)
        setLoading(false)
    }

    function handleSuggestions(query: string) {
        setSearch(query)
        apiCall(query, 20)
        setLimit(20)
    }

    const handleLikeToggle = (id: number) => {
        setLikes((prevLikes) => ({
            ...prevLikes,
            [id]: !prevLikes[id]
        }))
    }

    function handleLoad(limited: number) {
        setLimit(limited)
        apiCall(search, limited)
    }
    useEffect(() => {
        apiCall('snow mountains', limit)
    }, [])

    const router = useRouter()
    return (
        <div>
            <div className="flex px-6 gap-5 max-lg:flex max-lg:flex-col ">
                <div className="lg:flex gap-6 max-lg:grid max-lg:grid-flow-row max-lg:grid-cols-3">
                    {Suggestions.map((value, index) => {
                        return (
                            <Button
                                key={index}
                                disabled={search === value.type ? true : false}
                                className="p-2 rounded-3xl text-lg w-40 text-center max-lg:text-sm max-lg:w-24 max-lg:rounded-lg  cursor-pointer disabled:cursor-not-allowed text-light-wisteria-800 font-semibold bg-light-wisteria-400  hover:bg-light-wisteria-300 transition-all duration-200"
                                onClick={() => handleSuggestions(value.type)}
                            >
                                {value.type}
                            </Button>
                        )
                    })}
                </div>
                <div className="flex justify-end max-lg:justify-between lg:gap-2">
                    {' '}
                    <input
                        type="search"
                        placeholder="Search"
                        className="rounded-md lg:px-5 p-2  bg-light-wisteria-900 outline-none"
                        onChange={(e) => handleChange(e)}
                    />
                    <Button variant={'outline_wisteria'} onClick={() => apiCall(search, limit)}>
                        Search
                    </Button>
                </div>
            </div>
            {loading ? (
                <Loading></Loading>
            ) : (
                <div>
                    {' '}
                    <div className={` grid grid-flow-row lg:grid-cols-5 grid-cols-1 lg:gap-x-5 lg:gap-y-8 gap-y-4 p-5 `}>
                        {photos &&
                            photos.map((photo: RawPhoto) => (
                                <div key={photo.id} className="relative">
                                    <Image
                                        className="w-auto h-auto  rounded-sm border-2 border-light-wisteria-800 cursor-pointer lg:hover:scale-105 transition ease-in-out duration-300"
                                        width={500}
                                        height={500}
                                        src={photo.src.portrait}
                                        alt={photo.photographer}
                                        priority
                                        onClick={() => handleClick(photo.id)}
                                    />
                                    <p className="absolute bottom-2 left-2 opacity-100 transition-opacity duration-300 hover:opacity-100 bg-light-wisteria-600 text-light-wisteria-50 px-2 py-1 rounded-md">
                                        {photo.photographer}
                                    </p>
                                    <FaHeart
                                        className={`absolute top-2 cursor-pointer right-2 w-6 h-6  ${likes[photo.id] ? 'text-red-600' : 'text-white'}`}
                                        onClick={() => handleLikeToggle(photo.id)}
                                    />
                                </div>
                            ))}
                    </div>
                    <div className="flex justify-center p-2">
                        {limit < 80 && (
                            <Button
                                variant={'outline_wisteria'}
                                onClick={() => handleLoad(limit + 20)}
                            >
                                Load More
                            </Button>
                        )}
                    </div>
                </div>
            )}
        </div>
    )
}

export default Gallery
