"use client"
import { Skeleton } from "@/components/ui/skeleton";
import Lottie from "lottie-react";
import loader from "../../../../public/assets/loader.json";

const Loading = () => {
  return (
    <div>
      <div className="flex px-6 gap-5 max-xl:hidden">
        <div className="flex gap-4 ">
          <Skeleton className="rounded-3xl  p-5 w-40 bg-slate-400/40"></Skeleton>
          <Skeleton className="rounded-3xl  p-5 w-40 bg-slate-400/40"></Skeleton>
          <Skeleton className="rounded-3xl  p-5 w-40 bg-slate-400/40"></Skeleton>
          <Skeleton className="rounded-3xl  p-5 w-40 bg-slate-400/40"></Skeleton>
          <Skeleton className="rounded-3xl  p-5 w-40 bg-slate-400/40"></Skeleton>
          <Skeleton className="rounded-3xl  p-5 w-40 bg-slate-400/40"></Skeleton>
        </div>
        <div className="flex w-full justify-end gap-2 ">
          {" "}
          <Skeleton className="w-52 bg-slate-400/40" />
          <Skeleton className="w-36 bg-slate-400/40"></Skeleton>
          <Skeleton></Skeleton>
        </div>
      </div>
      <div
        className={` grid grid-flow-rows grid-cols-5 gap-2 py-3 px-8 max-xl:hidden `}
      >
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
        <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
      </div>
      <div className=" flex flex-col justify-center h-[100vh] overflow-hidden items-center w-screen xl:hidden">
        <Lottie animationData={loader}></Lottie>
      </div>
    </div>
  );
};

export default Loading;
