'use client'
import { rolesAndNames } from '@/app/constants/about-constants'
import { PhotoResponse, RawPhoto } from '@/app/types/photo-type'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription } from '@/components/ui/card'
import Image from 'next/image'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { FaArrowUpRightFromSquare } from 'react-icons/fa6'
import { fetchData } from '../gallery/service'

import Video from './aboutVideo'

const AboutPage = () => {
    const [photos, setPhotos] = useState<RawPhoto[] | null>(null)
    async function apiCall(query: string, limited: number) {
        const data = (await fetchData(query, limited)) as unknown as PhotoResponse
        setPhotos(data.photos)
    }
    useEffect(() => {
        apiCall('manager', 5)
    }, [])

    return (
        <div className="p-14">
            <div className="flex space-x-5">
                <div className="w-[40%] flex flex-col gap-10">
                    {' '}
                    <h1 className="text-[48px] font-semibold text-light-wisteria-600 ">
                        Meet our team of creators,{' '}
                        <span className="block">designers and world-class</span> problem solvers
                    </h1>
                    <span className="text-light-wisteria-300 text-lg text-start">
                        To be the company of our customers want us to be,it takes an{' '}
                        <span className="italic font-serif text-xl"> electric group </span>
                        of passionate operators. Get to know the people leading the way at{' '}
                        <span className="italic font-serif text-xl">success.</span>
                        <Link
                            href={'/contact'}
                            className="flex gap-[.3rem] underline hover:text-light-wisteria-100 transition-all duration-150 ease-in-out cursor-pointer"
                        >
                            {' '}
                            <p className="italic text-[12px] ">Contact us</p>
                            <FaArrowUpRightFromSquare className="h-7 w-3" />
                        </Link>
                    </span>
                    <div className="flex justify-between p-4  ">
                        <Button
                            variant={'outline_wisteria'}
                            className="w-72 font-normal h-16 rounded-none text-lg"
                        >
                            Our Story
                        </Button>
                        <Button
                            variant={'outline_wisteria'}
                            className="w-72 font-normal h-16 rounded-none text-lg"
                        >
                            <Video />
                        </Button>
                    </div>
                </div>
                <div className=" about-scroll w-[60%] overflow-x-auto flex-wrap">
                    {' '}
                    <div className="grid grid-flow-col grid-rows-1 gap-5 cursor-pointer p-3 overflow-visible ">
                        {photos?.map((photo, index) => {
                            return (
                                <div key={index}>
                                    <Card className="w-80 p-3 bg-black border-light-wisteria-600 text-center hover:scale-105 transition-all duration-500 ease-in-out  hover:bg-light-wisteria-950 ">
                                        <CardContent>
                                            <Image
                                                className="rounded-lg border-light-wisteria-200 border "
                                                src={photo.src.portrait}
                                                alt={''}
                                                width={600}
                                                height={600}
                                            ></Image>
                                        </CardContent>
                                        <>
                                            <span>{rolesAndNames[index].name}</span>
                                            <CardDescription>
                                                {rolesAndNames[index].role}
                                            </CardDescription>
                                        </>
                                    </Card>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AboutPage
