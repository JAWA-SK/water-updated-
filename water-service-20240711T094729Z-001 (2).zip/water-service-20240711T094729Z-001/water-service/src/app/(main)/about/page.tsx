import AboutPage from "./about"

const About = () => {
    return (
        <div>
            <AboutPage></AboutPage>
        </div>
    )
}

export default About
