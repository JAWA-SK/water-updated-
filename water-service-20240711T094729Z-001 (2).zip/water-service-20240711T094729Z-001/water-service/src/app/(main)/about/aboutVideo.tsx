import React, { useRef } from 'react'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger
} from '@/components/ui/dialog'
import YouTube from 'react-youtube'
import { FaCirclePlay } from 'react-icons/fa6'

const Video = () => {
    
    const opts = {
        height: '540',
        width: '840',
        playerVars: {
            autoplay: 1
        }
    }

    return (
        <div className="flex items-center justify-center w-screen h-screen">
            <Dialog>
                <DialogTrigger className="hover:underline flex justify-evenly gap-8 ">
                    <FaCirclePlay className="w-7 h-7" />
                    <span> Watch Video </span>
                </DialogTrigger>
                <DialogContent className=" max-w-full w-fit bg-light-wisteria-950/40">
                    <DialogHeader>
                        <DialogDescription>
                            <YouTube
                                videoId="C65iqOSCZOY"
                                opts={opts}
                                className="rounded-2xl border-2 border-light-wisteria-100 overflow-hidden"
                            />
                        </DialogDescription>
                    </DialogHeader>
                </DialogContent>
            </Dialog>
        </div>
    )
}

export default Video
