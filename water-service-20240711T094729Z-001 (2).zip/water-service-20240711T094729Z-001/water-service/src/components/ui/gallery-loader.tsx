import { Skeleton } from '@/components/ui/skeleton'

const Loading = () => {
    return (
        <div>
            <div className={` grid grid-flow-rows grid-cols-5 gap-2 py-3 px-8 `}>
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
                <Skeleton className="w-68 h-72 p-10 rounded-sm border-2 bg-slate-400/40" />
            </div>
        </div>
    )
}

export default Loading
