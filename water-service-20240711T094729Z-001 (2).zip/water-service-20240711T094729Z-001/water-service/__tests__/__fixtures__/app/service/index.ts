import { PhotoResponse } from "@/app/types/photo-type";


export const mockPhoto : PhotoResponse ={
    page: 2,
    per_page: 2,
    photos: []
}