import { FormDetail } from '@/app/types/form-detail-type'
import { UserFormDetail } from '@/app/types/user-details-type'
import { faker } from '@faker-js/faker'
import moment from 'moment'

export const mockUserDetail: UserFormDetail = {
    email: faker.internet.email(),
    lastName: faker.person.lastName(),
    firstName: faker.person.firstName(),
    phoneNo: String(faker.number.int()),
    date: faker.date.recent().toString(),
    address1: faker.lorem.words(3),
    address2: faker.lorem.words(3),
    state: faker.lorem.word(),
    country: faker.lorem.word(),
    service: faker.lorem.word()
}

export const mockFormDetail: FormDetail = {
    email: faker.internet.email(),
    lastName: faker.person.lastName(),
    firstName: faker.person.firstName(),
    phoneNo: String(faker.number.int()),
    address1: faker.location.streetAddress(),
    date: moment().format('MMMM Do YYYY'),
    service: 'agriculture',
    pincode: Number(faker.location.zipCode()),
    address2: faker.location.streetAddress(),
    country: faker.location.country(),
    state: faker.location.state()
}

export const invalidMockForFirstName = {
    firstName:  faker.lorem.word().charAt(0).toUpperCase()
}
export const invalidMockForLastName = {
    lastName: ''
}
export const invalidMockForEmail = {
    email: faker.internet.email() + faker.number.int()
}

export const invalidMockForPincode = {
    minPincode: faker.number.int(2),
    maxPincode: faker.number.int(10)
}
