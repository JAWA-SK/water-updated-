
import FormComponent from '@/app/(main)/form/form-component'
import { FormLabels } from '@/app/constants/form-label-constants'
import {
    FormPlaceHolders,
    FormValidationConstants
} from '@/app/constants/form-validation-constants'
import { InputLabels } from '@/app/constants/input-label-constants'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import "jest-canvas-mock"
import moment from 'moment'
import {
    invalidMockForEmail,
    invalidMockForFirstName,
    invalidMockForLastName,
    invalidMockForPincode,
    mockFormDetail,
    mockUserDetail
} from '../../../app/form'

describe('should render a form components', () => {
    it('should render a labels', () => {
        render(<FormComponent />)
        expect(screen.getByText(FormLabels.FIRST_NAME)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.LAST_NAME)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.DATE)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.SERVICE)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.MOBILE)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.EMAIL)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.ADDRESS_1)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.ADDRESS_2)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.COUNTRY)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.STATE)).toBeInTheDocument()
        expect(screen.getByText(FormLabels.PIN_CODE)).toBeInTheDocument()
    })

    it('should render a submit button for a form', () => {
        render(<FormComponent />)
        expect(screen.getByText(InputLabels.SUBMIT_FORM)).toBeInTheDocument()
    })

    it('should render all place holders in the form', () => {
        render(<FormComponent  />)
        expect(screen.getByPlaceholderText(FormPlaceHolders.FIRST_NAME)).toBeInTheDocument()
        expect(screen.getByPlaceholderText(FormPlaceHolders.LAST_NAME)).toBeInTheDocument()
        expect(screen.getByPlaceholderText(FormPlaceHolders.MOBILE)).toBeInTheDocument()
        expect(screen.getByPlaceholderText(FormPlaceHolders.EMAIL)).toBeInTheDocument()
        expect(screen.getByPlaceholderText(FormPlaceHolders.ADDRESS_1)).toBeInTheDocument()
        expect(screen.getByPlaceholderText(FormPlaceHolders.ADDRESS_2)).toBeInTheDocument()
        const pincode = screen.getByTestId("pincode")
        fireEvent.change(pincode, { target: { value: "600103" } })
        expect(pincode).toHaveValue("600103")
    })

    it('should display error when service is not selected', async () => {
        render(<FormComponent/>)

        const submitButton = screen.getByRole(InputLabels.BUTTON, {
            name: InputLabels.SUBMIT_FORM
        })
        fireEvent.click(submitButton)
        const firstNameError = await screen.findByText(FormValidationConstants.MISSING_FIRST_NAME)
        const lastNameError = await screen.findByText(FormValidationConstants.MISSING_LAST_NAME)
        const phoneNoError = await screen.findByText(FormValidationConstants.MISSING_PHONE_NO)
        const emailError = await screen.findByText(FormValidationConstants.MISSING_EMAIL)
        const addressError = await screen.findByText(FormValidationConstants.MISSING_ADDRESS)

        expect(firstNameError).toBeInTheDocument()
        expect(lastNameError).toBeInTheDocument()
        expect(emailError).toBeInTheDocument()
        expect(phoneNoError).toBeInTheDocument()
        expect(addressError).toBeInTheDocument()
    })

    it('should render a text for invalid value in the form component fields', async () => {
        render(<FormComponent />)

        const invalidDataForFirstName = invalidMockForFirstName
        const invalidDataForLastName = invalidMockForLastName
        const invalidDataForEmail = invalidMockForEmail
        const minPincodeValidation = invalidMockForPincode.minPincode
        const maxPincodeValidation = invalidMockForPincode.maxPincode

        fireEvent.change(screen.getByPlaceholderText(FormPlaceHolders.FIRST_NAME), {
            target: { value: invalidDataForFirstName }
        })
        fireEvent.change(screen.getByPlaceholderText(FormPlaceHolders.LAST_NAME), {
            target: { value: invalidDataForLastName }
        })
        fireEvent.change(screen.getByPlaceholderText(FormPlaceHolders.EMAIL), {
            target: { value: invalidDataForEmail }
        })
        fireEvent.change(screen.getByPlaceholderText(FormLabels.PIN_CODE), {
            target: { value: minPincodeValidation }
        })
        fireEvent.change(screen.getByPlaceholderText(FormLabels.PIN_CODE), {
            target: { value: maxPincodeValidation }
        })

        const submitButton = screen.getByRole(InputLabels.BUTTON, {
            name: InputLabels.SUBMIT_FORM
        })
        fireEvent.click(submitButton)
        const firstNameError = await screen.findByText(
            FormValidationConstants.FIRST_NAME_VALIDATION
        )
        const lastNameError = await screen.findByText(FormValidationConstants.LAST_NAME_VALIDATION)
        const minPincodeError = await screen.findByText(
            FormValidationConstants.MIN_PINCODE_VALIDATION
        )
        const maxPincodeError = await screen.findByText(
            FormValidationConstants.MAX_PINCODE_VALIDATION
        )
        const emailError = await screen.findByText(FormValidationConstants.INVALID_EMAIL)
        expect(firstNameError).toBeInTheDocument()
        expect(lastNameError).toBeInTheDocument()
        expect(emailError).toBeInTheDocument()
        expect(minPincodeError).toBeInTheDocument()
        expect(maxPincodeError).toBeInTheDocument()
    })

    it('it for proper date change', async () => {
        const mockData = mockUserDetail
        render(<FormComponent  />)
        const dateField = screen.getByTestId("date")
        await userEvent.click(dateField)
        const selectedDate = moment(new Date()).format('D')
        await waitFor(async () => {
            userEvent.click(screen.getAllByText(selectedDate)[0])
        })
        expect(dateField).toBeInTheDocument()
    })

    it('should render select fields in a form', async () => {
        const mockFormData = mockFormDetail
        render(<FormComponent />)
        const selectService = screen.getAllByRole(InputLabels.COMBO_BOX)
        await userEvent.click(selectService[0])
        const selectedService = screen.getByRole(InputLabels.OPTION, {
            name: mockFormData.service
        })
        expect(selectedService).toBeInTheDocument()
    })
})
