import ContactPage from "@/app/(main)/contact/page"
import { render,screen } from "@testing-library/react"
import { ICON_TEST_ID } from "../../../../__utils__/testConstants"

describe('Test for contact page', () => {
    it('should render a header text properly', async() => {
        render(<ContactPage />)
        const textComponent = screen.getByText('Get In')
        const subText= screen.getByText('Touch')

        expect(textComponent).toBeInTheDocument()
        expect(subText).toBeInTheDocument()
    })

    it('should render a sales chat card', async() => {
        render(<ContactPage />)
        const percentIcon = screen.getByTestId("percentage")
        const cardHeader= screen.getByText('Sales chat')

        expect(percentIcon).toBeInTheDocument()
        expect(cardHeader).toBeInTheDocument()
    })

    it('should render a support chat card', async() => {
        render(<ContactPage />)
        const chatIcon = screen.getByTestId("chatBox")
        const cardHeader= screen.getByText('Support chat')

        expect(chatIcon).toBeInTheDocument()
        expect(cardHeader).toBeInTheDocument()
    })

    it('should render a visit us card', async() => {
        render(<ContactPage />)
        const locationIcon = screen.getByTestId("location")
        const cardHeader= screen.getByText('Visit us')

        expect(locationIcon).toBeInTheDocument()
        expect(cardHeader).toBeInTheDocument()
    })

    it('should render a call us card', async() => {
        render(<ContactPage />)
        const callIcon = screen.getByTestId("call")
        const cardHeader= screen.getByText('Call us')

        expect(callIcon).toBeInTheDocument()
        expect(cardHeader).toBeInTheDocument()
    })
})