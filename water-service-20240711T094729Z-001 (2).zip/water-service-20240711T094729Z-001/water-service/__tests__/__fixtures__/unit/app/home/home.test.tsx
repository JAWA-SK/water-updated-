import Root from '@/app/page'
import '@testing-library/jest-dom'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

describe('Test for home page', () => {
    it('should render a text and form components', async() => {
        render(<Root />)
        screen.debug(undefined,Infinity)
        const textComponent = screen.getByTestId('quote')
        expect(textComponent).toBeInTheDocument()
    })

    it('render button correctly', async() => {
        render(<Root />)
        const button = screen.getByRole("button", {
            name: "Continue"
        });
        await userEvent.click(button);

        expect("What we do").toBeDefined()
    })
})
