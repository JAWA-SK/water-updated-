
import TextComponent from '@/app/(main)/form/text-component'
import { render, screen } from '@testing-library/react'

describe('Test for a heading, text and subtexts', () => {
    it('should render a texts', () => {
        render(<TextComponent />)
        const firstLine = screen.getByText('Only 20%')
        const secondLine = screen.getByText('of waste water is treated')
        const thirdLine = screen.getByText(
            'The average family can waste 180 gallons per week, or 9,400 gallons'
        )
        const fourthLine = screen.getByText('of water annually, from household leaks.')
        expect(firstLine).toBeInTheDocument()
        expect(secondLine).toBeInTheDocument()
        expect(thirdLine).toBeInTheDocument()
        expect(fourthLine).toBeInTheDocument()
    })
})
