import { fetchData } from '@/app/(main)/gallery/service'

describe('Test the fetchData service', async () => {
    it('should call the api.get with correct parameters for fetchProductsService', async () => {
        const searchQuery = 'water'
        const limited = 2
        await fetchData(searchQuery, limited)
        expect(fetchData).toHaveBeenCalledWith(
            `https://api.pexels.com/v1/search?query=${searchQuery}&page=1&per_page=${limited}`,
            {
                headers: {
                    Authorization: 'wpiX7X0BirF94NYHbUwWv3oL2uHnfla0fPHLF5a1brO7IsjRzmcLqVyT'
                }
            }
        )
    })
})
