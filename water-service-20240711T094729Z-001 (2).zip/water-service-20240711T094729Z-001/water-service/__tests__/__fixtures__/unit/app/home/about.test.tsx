import AboutPage from '@/app/(main)/about/about'
import { render, screen } from '@testing-library/react'

jest.mock('../../../../../src/app/(main)/gallery/service', () => ({
    fetchData: jest.fn()
}))

describe('Test for contact page', () => {
    it('should render a header text properly', async () => {
        render(<AboutPage />)
        const textComponent = screen.getByText('Meet our team of creators,')
        const subText = screen.getByText('designers and world-class')

        expect(textComponent).toBeInTheDocument()
        expect(subText).toBeInTheDocument()
    })

    it('should render a our story button', async () => {
        render(<AboutPage />)
        const button = screen.getByRole('button', {
            name: 'Our Story'
        })

        expect(button).toBeDefined()
    })

    it('should render a watch video button', async () => {
        render(<AboutPage />)
        const button = screen.getByRole('button', {
            name: 'Our Story'
        })

        expect(button).toBeDefined()
    })
})
