export const ICON_TEST_ID = {
    PERCENT_ICON: "FaPercentage",
    SEARCH_ICON: "SearchOutlinedIcon",
    MORE_ICON: "MoreVertRoundedIcon"
}